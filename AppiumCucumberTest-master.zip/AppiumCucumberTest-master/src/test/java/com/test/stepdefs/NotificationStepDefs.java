package com.test.stepdefs;

import cucumber.api.java.en.Then;
import org.junit.Assert;

/**
 * Created by priyankp.shah on 9/17/15.
 */
public class NotificationStepDefs {


    @Then("^Message notification should be visible$")
    public void message_notification_should_be_visible() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        Assert.assertTrue(true);
    }


}
